# Fundação — revisão documental r9


O ERP preserva o trabalho elegível enquanto a pessoa preenche uma ficha e informa com clareza se o salvamento foi confirmado. Os dados temporários ficam cifrados neste dispositivo, ligados à conta, empresa e ficha. Antes de clicar em **Salvar**, não há envio nem operação na fila.

**Salvar** fixa uma intenção imutável: ID, versão esperada, conteúdo e anexos elegíveis. A interface mostra **Salvamento pendente** até a confirmação protegida do servidor. Só entram na fila durável e cifrada as cópias cuja persistência local foi confirmada e que podem ser recuperadas com segurança. Novas edições ficam separadas da intenção em trânsito.

Na retomada, o ERP valida online a autorização atual e consulta a operação original. Só repete quando o contrato permitir, usando o mesmo ID, versão e conteúdo. Resultado incerto não permite reenvio cego. A confirmação remove apenas a versão reconhecida e preserva edições posteriores. Conflito exige revisão e decisão explícita antes de uma nova intenção. Ações sem fila também preservam a incerteza quando não há confirmação.

A interface apresenta **Falha**, um número estável e a próxima ação. 1101: cópia confirmada na fila e falha temporária; 1102: confirmação desconhecida, consultar; 1103: guarda local esperada falhou ou se perdeu; 1104: conflito de versão, revisar; 1105: sessão ou permissão inválida, revalidar; 1106: campos inválidos, corrigir. O [catálogo](modules/MOD-001/save-failure-catalog.md) define condições e precedência. Confirmação protegida permanece **Salvo**, mesmo se a limpeza local precisar ser repetida, sem reenviar a gravação.

Troca de conta/empresa, logout, expiração ou revogação conhecidos bloqueiam abertura e retomada. Outra conta não recupera a cópia, mesmo tendo acesso à mesma ficha. Reabrir depende de autorização online do titular. Não há promessa de recuperação após remoção dos dados pelo navegador, nem de processamento com o ERP fechado. RPO zero do servidor não cobre rascunho local ainda não confirmado.


[Leitura do produto e pendências](modules/MOD-001/product-behavior-r9.md) · [Task r9](tasks/MOD-001/task.md) · [Contrato](modules/MOD-001/phase-spec.md). Abaixo permanece contexto histórico de preparação geral; os estados e revisões antigos não são estado corrente da Fundação. A governança integral está nos contratos e no registro, sem liberação operacional.

---

> Contexto TFD · 493 palavras · 919 tokens (o200k_base)

# GAEVA OS — pacote integrado para aprovação

GAEVA-TRANSFORM-001 / preparation/final-spec-and-tasks / MT-A02 spec-finalization-r5. Executor TFD-architecture agent-65a76b70-79bc-4539-b8b9-840998b76a10; main agent-97250e7c-4112-4c26-bcaf-4d7066200462; retomada95d19990-23ae-405b-96fd-20cabd50f0a8. **DRAFT final de preparação para QA independente e posterior decisão humana. Não é implementação, G6 PASS ou ambiente pronto.**

## O que submeter à revisão

Estado atual: spec-finalization-r5, onze Tasks validadas em modo normal e estimativas de todas as fases em `estimates/`. MOD001 permanece revision4; MOD002/004 revision2; os oito contratos alterados passam a revision3. QA r4 encerrou F01/F02 da Fundacao; o delta de estimativas requer QA independente. [Recibo atual](finalization-r5.md) e [manifesto atual](finalization-r5-manifest.json) vinculam os hashes. `submission-manifest.json`, `native-checks.json`, `receipt.md` e `conversion-provenance.json` sao evidencias historicas preservadas; o manifesto r5 e a submissao atual. Nenhum gate humano ou autorizacao operacional foi concedido.

1. [Spec integrada](integrated-spec.md), [dados e transações](data-contracts.md), [interfaces propostas](openapi.json), [páginas/componentes](pages-components.md).
2. [Plano e validação por fase](phase-plan.md), [folha de decisões para aprovação](approval-decisions.md), specs individuais em `modules/` e Tasks indicadas no [registro canônico](task-registry.json).
3. [Fontes congeladas](source-manifest.json), [recibo](receipt.md) e manifesto de submissão `submission-manifest.json`: amarram a revisão atual da spec, Discovery, Tasks e respectivas vistas; pareceres dos setores são entradas, não aprovação desta síntese.

Architecture MT-A01r2, Discovery MT-D01r2, UIUX MT-U01r1 e DevOps MT-O01r1 têm PASS documental nos caminhos preservados de reviews. A síntese resolve a prévia modeless e incorpora tabela de impressão e DF01–07. Conteúdo qualificado é reutilizado por referência normativa, sem copiar seus grandes pacotes. Novas interfaces/tabelas são propostas explícitas; rotas/colunas atuais continuam identificadas em C00 da arquitetura.

## Limites de aprovação

Uma base GAEVA OS com materiais/processos genéricos FilaOps e ChatbotX escolhido. Fundação→Plataforma→contratos MOD003/006/008/011→piloto Comercial. Mensagens cede entrada ao Comercial gradualmente, sem perda de histórico/anexos/notificações. Sem estudo por outra empresa, segundo banco lógico por conveniência, rewrite de chat, novo produto ou microserviço por módulo.

G0 permanece AWAITING_APPROVAL na consulta read-only do workflow Comercial; G0.5/G1/G6 não são inventados. Aprovar este pacote futuramente deve identificar recorte/fase/revisão, decisões D aceitas e bloqueios mantidos. Nenhum desses campos é marcado aprovado nesta entrega. PR/Issue/Git não estão publicados/vinculados: negação histórica de .git B não foi retentada. Raiz A preservada.

Q02 fonte-imagem, Q03 adapter ChatbotX, Q04 restore e Q05 PRO/anexos têm critérios de saída e bloqueiam somente execução dependente. MOD010 e recortes ainda sem PRD permanecem planejamento, sem promessa de implementação pronta. Os Tasks draft não autorizam seus allowed_paths de execução; nesta preparação só se escreveu sob `spec/`.

Precedência corrigida pelo usuário/main: schemas/task.json e examples/task.example.json regem as Tasks nativas. O template v2 importado pertence a outro workflow; suas restrições conceituais são preservadas nos campos nativos e specs vinculadas, sem alegar validação de equivalência v2. [Proveniência](conversion-provenance.json) preserva hashes anteriores e mapeamento de campos; [checks por Task](native-checks.json) distinguem validação normal/draft. Não houve conserto ou alteração da biblioteca. Validade estrutural e aprovação funcional/humana são verificações distintas.

## Candidato documental MOD001 r9

[Task proposta](tasks/MOD-001/task.json) e [spec completa](modules/MOD-001/phase-spec.md) consolidam somente Fundação em r9, ainda draft/QA corrente pendente. O aceite comunicado cobre escopo documental, não gate ou operação. Pesquisa anterior tem PASS limitado; novos bytes exigem QA. Registro histórico acima não é estado/gate Foundation, nem substitui fonte r5 preservada nas preimages.
